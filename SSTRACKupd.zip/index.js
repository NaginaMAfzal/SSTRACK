require = require('esm')(module);
module.exports = require('./app.js');
